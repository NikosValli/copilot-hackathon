using System.Net.Http;
using System.Threading.Tasks;
using NUnit.Framework;
using Microsoft.AspNetCore.Mvc.Testing;
using backend;
using System.Text.Json;

namespace Backend.Tests
{
    public class MovieEndpointTests
    {
        private WebApplicationFactory<Program> _factory;
        private HttpClient _client;

        [SetUp]
        public void Setup()
        {
            _factory = new WebApplicationFactory<Program>();
            _client = _factory.CreateClient();
        }

        [Test]
        public async Task TestSeedMoviesEndpoint()
        {
            var response = await _client.PostAsync("/seed", null);
            response.EnsureSuccessStatusCode();
            var content = await response.Content.ReadAsStringAsync();
            var result = JsonSerializer.Deserialize<backend.Models.SeedResult>(content);
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Seeded);
        }

        [Test]
        public async Task TestListMoviesEndpoint()
        {
            // Ensure the database is seeded before listing movies
            var seedResponse = await _client.PostAsync("/seed", null);
            seedResponse.EnsureSuccessStatusCode();

            var response = await _client.GetAsync("/movies");
            response.EnsureSuccessStatusCode();
            var content = await response.Content.ReadAsStringAsync();
            var movies = JsonSerializer.Deserialize<backend.Models.MovieDto[]>(content);
            Assert.IsNotNull(movies, "Movies should not be null");
            Assert.That(movies.Length, Is.EqualTo(5), "Should return 5 seeded movies");
            foreach (var movie in movies)
            {
                Assert.IsFalse(string.IsNullOrWhiteSpace(movie.Title), "Movie title should not be empty");
                Assert.IsNotNull(movie.Category, "Movie category should not be null");
                Assert.IsFalse(string.IsNullOrWhiteSpace(movie.Category.Name), "Category name should not be empty");
            }
        }
    }
}
