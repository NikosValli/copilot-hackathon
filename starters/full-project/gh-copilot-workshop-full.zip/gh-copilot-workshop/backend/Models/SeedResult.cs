namespace backend.Models
{
    public class SeedResult
    {
        public bool Seeded { get; set; }
    }
}
