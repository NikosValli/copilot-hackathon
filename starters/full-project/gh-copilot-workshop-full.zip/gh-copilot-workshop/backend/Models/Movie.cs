using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace backend.Models
{
    public class Movie
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; } = string.Empty;

        [StringLength(500)]
        public string? Description { get; set; }

        [ForeignKey("Category")]
        public int CategoryId { get; set; }

        public Category? Category { get; set; }

        // Navigation property for many-to-many relationship with MovieUser
        public List<MovieUser> MovieUsers { get; set; } = new List<MovieUser>();
    }
}

// Checklist
// - [x] Create class structure
// - [x] Implement navigation properties if needed
// - [x] Add data annotations for validation
