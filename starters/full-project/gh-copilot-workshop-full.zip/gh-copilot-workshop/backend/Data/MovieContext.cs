using Microsoft.EntityFrameworkCore;
using backend.Models;

namespace backend.Data
{
    public class MovieContext : DbContext
    {
        public MovieContext(DbContextOptions<MovieContext> options)
            : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Movie> Movies { get; set; }
        public DbSet<MovieUser> MovieUsers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // One-to-many: Category -> Movies
            modelBuilder.Entity<Category>()
                .HasMany(c => c.Movies)
                .WithOne(m => m.Category)
                .HasForeignKey(m => m.CategoryId);

            // Many-to-many: Movie <-> MovieUser
            modelBuilder.Entity<Movie>()
                .HasMany(m => m.MovieUsers)
                .WithMany(mu => mu.Movies)
                .UsingEntity<Dictionary<string, object>>(
                    "MovieMovieUser",
                    j => j
                        .HasOne<MovieUser>()
                        .WithMany()
                        .HasForeignKey("MovieUserId")
                        .OnDelete(DeleteBehavior.Cascade),
                    j => j
                        .HasOne<Movie>()
                        .WithMany()
                        .HasForeignKey("MovieId")
                        .OnDelete(DeleteBehavior.Cascade)
                );
        }
    }
}
