# Models Relationship Diagram

```mermaid
classDiagram
    Category "1" --o "*" Movie : contains
    Movie "*" --o "*" MovieUser : watched by
    
    class Category {
        int Id
        string Name
        List<Movie> Movies
    }
    class Movie {
        int Id
        string Title
        int CategoryId
        Category Category
        List<MovieUser> MovieUsers
    }
    class MovieUser {
        int Id
        string FullName
        string Email
        List<Movie> Movies
    }
```

<!-- Checklist
- [x] Create mermaid diagram for relationships
- [x] Show one-to-many Category-Movie
- [x] Show many-to-many Movie-MovieUser
- [x] Save in diagrams/models-relationship.md
-->
