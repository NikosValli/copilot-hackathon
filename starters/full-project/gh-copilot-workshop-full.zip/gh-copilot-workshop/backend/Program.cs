
using Microsoft.EntityFrameworkCore;
using backend.Models;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        builder.Services.AddDbContext<backend.Data.MovieContext>(options =>
            options.UseInMemoryDatabase("MoviesDb"));

        // Add CORS policy to allow frontend requests
        builder.Services.AddCors(options =>
        {
            options.AddPolicy("AllowFrontend",
                policy => policy.WithOrigins("http://localhost:5173")
                                .AllowAnyHeader()
                                .AllowAnyMethod());
        });

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            // OpenAPI/Swagger setup removed for .NET 8 compatibility
        }

        // Only use CORS and HTTPS in non-test environments
        if (builder.Environment.EnvironmentName != "Test")
        {
            app.UseCors("AllowFrontend");
            // app.UseHttpsRedirection();
        }

        // Seed endpoint: POST /seed
        app.MapPost("/seed", async (backend.Data.MovieContext db, HttpContext context) =>
        {
            db.Categories.RemoveRange(db.Categories);
            db.Movies.RemoveRange(db.Movies);
            await db.SaveChangesAsync();

            var categories = new List<backend.Models.Category>
            {
                new() { Name = "Sci-Fi" },
                new() { Name = "Crime" },
                new() { Name = "Drama" },
                new() { Name = "Action" }
            };
            db.Categories.AddRange(categories);
            await db.SaveChangesAsync();

            int GetCategoryId(string name) => categories.First(c => c.Name == name).Id;

            var movies = new List<backend.Models.Movie>
            {
                new() { Title = "Inception", Description = "", CategoryId = GetCategoryId("Sci-Fi") },
                new() { Title = "The Godfather", Description = "", CategoryId = GetCategoryId("Crime") },
                new() { Title = "Pulp Fiction", Description = "", CategoryId = GetCategoryId("Crime") },
                new() { Title = "The Shawshank Redemption", Description = "", CategoryId = GetCategoryId("Drama") },
                new() { Title = "The Dark Knight", Description = "", CategoryId = GetCategoryId("Action") }
            };
            db.Movies.AddRange(movies);
            await db.SaveChangesAsync();

            context.Response.ContentType = "application/json";
            await System.Text.Json.JsonSerializer.SerializeAsync(context.Response.Body, new backend.Models.SeedResult { Seeded = true });
        });

        // Get movies endpoint: GET /movies
        app.MapGet("/movies", async (backend.Data.MovieContext db, HttpContext context) =>
        {
            var movies = await db.Movies
                .Include(m => m.Category)
                .Select(m => new backend.Models.MovieDto
                {
                    Id = m.Id,
                    Title = m.Title,
                    Description = m.Description,
                    Category = m.Category != null ? new backend.Models.MovieCategoryDto
                    {
                        Id = m.Category.Id,
                        Name = m.Category.Name
                    } : null
                })
                .ToListAsync();
            context.Response.ContentType = "application/json";
            await System.Text.Json.JsonSerializer.SerializeAsync(context.Response.Body, movies);
        });

    app.Run();
    }
}

