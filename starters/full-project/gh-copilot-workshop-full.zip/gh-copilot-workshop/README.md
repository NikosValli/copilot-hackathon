# gh-copilot-workshop

Code Review with Copilot