<template>
  <section class="w-full max-w-2xl mx-auto bg-white rounded-lg shadow p-6 mt-6">
    <div class="flex justify-between items-center mb-4">
      <h2 class="text-2xl font-bold text-gray-800">Movie List</h2>
      <button @click="refreshMovies" title="Refresh" class="p-2 rounded-lg hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500">
        <!-- Heroicons: Arrow Path (refresh) -->
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6 text-blue-500">
          <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12a7.5 7.5 0 0113.5-5.25M19.5 12a7.5 7.5 0 01-13.5 5.25M19.5 12V8.25a.75.75 0 00-.75-.75H15.75M4.5 12v3.75a.75.75 0 00.75.75H8.25" />
        </svg>
      </button>
    </div>
    <div v-if="loading" class="flex justify-center items-center h-32">
      <span class="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></span>
      <span class="ml-2 text-gray-500">Loading movies...</span>
    </div>
    <ul v-else>
      <li v-for="movie in movies" :key="movie.id" class="border-b py-2 flex justify-between items-center">
        <span class="font-medium text-gray-700">{{ movie.title }}</span>
        <span class="text-sm text-gray-500">{{ movie.year }}</span>
      </li>
      <li v-if="movies.length === 0" class="text-gray-400 py-2">No movies found.</li>
    </ul>
  </section>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const movies = ref([]);
const loading = ref(true);

async function fetchMovies() {
  loading.value = true;
  try {
    const response = await fetch('http://localhost:5065/movies');
    if (response.ok) {
      movies.value = await response.json();
    } else {
      movies.value = [];
    }
  } catch (error) {
    movies.value = [];
  } finally {
    loading.value = false;
  }
}

function refreshMovies() {
  fetchMovies();
}

onMounted(fetchMovies);
</script>
