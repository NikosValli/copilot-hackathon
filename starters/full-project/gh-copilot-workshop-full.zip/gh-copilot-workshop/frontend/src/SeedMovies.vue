<template>
  <section class="w-full max-w-2xl mx-auto bg-white rounded-lg shadow p-6 mt-6">
    <h2 class="text-2xl font-bold mb-4 text-gray-800">Seed Movies</h2>
    <button
      class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded shadow flex items-center"
      @click="seedMovies"
      :disabled="loading"
    >
      <span v-if="loading" class="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white mr-2"></span>
      <span>{{ loading ? 'Seeding...' : 'Seed Movies' }}</span>
    </button>
    <p v-if="message" class="mt-4 text-green-600">{{ message }}</p>
    <p v-if="error" class="mt-4 text-red-600">{{ error }}</p>
  </section>
</template>

<script setup>
import { ref } from 'vue';

const loading = ref(false);
const message = ref('');
const error = ref('');

async function seedMovies() {
  loading.value = true;
  message.value = '';
  error.value = '';
    try {
      const response = await fetch('http://localhost:5065/seed', { method: 'POST' });
      if (response.ok) {
        message.value = 'Movies seeded successfully!';
      } else {
        error.value = 'Failed to seed movies.';
      }
  } catch (err) {
    error.value = 'Error occurred while seeding.';
  } finally {
    loading.value = false;
  }
}
</script>
