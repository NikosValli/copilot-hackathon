<template>
  <main class="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
    <SeedMovies />
    <MovieList />
  </main>
</template>

<script setup>
import MovieList from './MovieList.vue';
import SeedMovies from './SeedMovies.vue';
</script>

<style scoped></style>
